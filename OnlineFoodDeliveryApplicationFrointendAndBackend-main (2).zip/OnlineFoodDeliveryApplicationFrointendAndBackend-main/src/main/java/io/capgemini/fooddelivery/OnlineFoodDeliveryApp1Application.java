package io.capgemini.fooddelivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineFoodDeliveryApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineFoodDeliveryApp1Application.class, args);
	}

}
